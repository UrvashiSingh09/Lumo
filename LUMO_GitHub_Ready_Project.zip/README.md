# LUMO – Emotional Finance Journal 🧘‍♀️💸

LUMO helps users connect their emotions with their spending habits, creating a mindful and judgment-free financial experience.

## 🔍 Features
- Mood-Based Expense Logging
- Weekly Emotional Reflection Journal
- AI-Powered Emotional Insight Engine
- Kind Nudges and Affirmations

## 🛠 Tech Stack
- Frontend: React.js
- Backend: Node.js, Express
- Database: MongoDB
- AI Engine: Python (Sentiment Analysis + GPT)
- Hosting: Firebase or Vercel (Frontend), Render/Heroku (Backend)

## 🚀 How to Run

### Frontend
```bash
cd frontend
npm install
npm start
```

### Backend
```bash
cd backend
npm install
node server.js
```

### AI Engine
```bash
cd ai_engine
python emotion_analysis.py
```

## 📄 License
This project is licensed under the MIT License.

---
Made with 💛 by Team LUMO.
