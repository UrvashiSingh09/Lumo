def get_nudge(emotion):
    if emotion == 'stress': return 'Take a deep breath. It’s okay to pause.'
    return 'Keep tracking your emotions and spending mindfully!'