import React from 'react';
function ExpenseLogger() {
  return <div>Log your expense with mood here</div>;
}
export default ExpenseLogger;