import React from 'react';
import ExpenseLogger from './components/ExpenseLogger';
function App() {
  return <div><h1>LUMO – Emotional Finance Journal</h1><ExpenseLogger /></div>;
}
export default App;